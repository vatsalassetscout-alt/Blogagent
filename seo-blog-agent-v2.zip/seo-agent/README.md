# SEO Blog Agent — Vercel Deploy Guide

## Deploy in 5 minutes (free)

### Step 1 — Upload to GitHub
1. Go to https://github.com/new
2. Create a new repo called `seo-blog-agent`
3. Upload all files from this zip (drag & drop)
4. Click "Commit changes"

### Step 2 — Deploy to Vercel
1. Go to https://vercel.com and sign up free (use GitHub login)
2. Click "Add New Project"
3. Import your `seo-blog-agent` GitHub repo
4. Click Deploy — wait 1 minute

### Step 3 — Add your API Key (IMPORTANT)
1. In Vercel dashboard → your project → Settings → Environment Variables
2. Add:
   - Name:  GEMINI_API_KEY
   - Value: AIzaSyCddrAAtqyxs_LemEfEPn3nnD5TeOzFwcM
3. Click Save
4. Go to Deployments → click the 3 dots → Redeploy

### Done!
Your site is live at: https://seo-blog-agent.vercel.app
(or whatever Vercel gives you)

## File structure
```
seo-blog-agent/
├── vercel.json          ← Vercel routing config
├── package.json         ← Node config
├── api/
│   └── gemini.js        ← Server API (key is safe here)
└── public/
    └── index.html       ← Frontend UI
```

## Security note
Your API key is stored as an environment variable on Vercel's servers.
It is NEVER exposed in the browser. The frontend calls /api/gemini
which runs on the server and makes the Gemini request securely.
